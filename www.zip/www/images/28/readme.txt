Nombre de la carpeta: distancia del lado superior desde el puente

El nombre del archivo contiene los siguientes elementos:

[altura]-[tipo_de_puente]-[radio_esquina_inferior_externa]_[COLOR].PNG (ejemplo: 18-2-08_AZUL.png)
